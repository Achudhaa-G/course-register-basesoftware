from flask import Blueprint, jsonify

main = Blueprint('main', __name__)

@main.route("/courses")
def get_courses():
    return jsonify({"courses": ["Math", "Science", "History"]})
