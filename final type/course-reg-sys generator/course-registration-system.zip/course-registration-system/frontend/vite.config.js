import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/courses': 'http://localhost:5000',
      '/auth': 'http://localhost:5000',
      '/admin': 'http://localhost:5000'
    }
  }
})